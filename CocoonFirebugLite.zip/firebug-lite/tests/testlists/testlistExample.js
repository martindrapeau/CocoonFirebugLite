FBTest.loadTestList([
    { page: "examples/async.html" },
    { page: "examples/sync.html" },
    { page: "examples/fail.html" }
]);